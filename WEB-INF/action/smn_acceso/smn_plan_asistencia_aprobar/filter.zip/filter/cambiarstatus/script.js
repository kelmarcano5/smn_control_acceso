//addNew();
//alertBox ('${lbl:b_record_updated}', '${lbl:b_continue_button}', null, 'setFocusOnForm("form1"); search();');
search();
alertBox('El registro fue modificado de la base de datos', 'Continuar', null, null);
