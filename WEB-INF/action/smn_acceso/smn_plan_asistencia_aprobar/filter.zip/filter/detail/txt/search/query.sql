select
	smn_plan_asistencia.*
from
	smn_control_acceso.smn_plan_asistencia
where
	smn_plan_asistencia_id = ${fld:id}
