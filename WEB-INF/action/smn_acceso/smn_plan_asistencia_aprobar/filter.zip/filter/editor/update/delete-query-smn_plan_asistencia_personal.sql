delete from smn_control_acceso.smn_plan_asistencia_personal
 WHERE  smn_plan_asistencia_id= ${fld:id}