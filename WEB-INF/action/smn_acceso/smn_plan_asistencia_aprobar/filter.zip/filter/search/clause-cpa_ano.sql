 and
 	smn_plan_asistencia.cpa_ano=${fld:cpa_ano}