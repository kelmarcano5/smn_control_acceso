 and
 	smn_plan_asistencia.cpa_fecha_desde_cal>=${fld:cpa_fecha_desde_cal}