 and
 	smn_plan_asistencia.cpa_fecha_generado<=${fld:cpa_fecha_generado_fin}