 and
 	smn_plan_asistencia.cpa_fecha_hasta_cal<=${fld:cpa_fecha_hasta_cal}