 and
 	smn_plan_asistencia.cpa_fecha_registro<=${fld:cpa_fecha_registro_fin}