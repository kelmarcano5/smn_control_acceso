 and
 	smn_plan_asistencia.cpa_fecha_vigencia<=${fld:cpa_fecha_vigencia_fin}