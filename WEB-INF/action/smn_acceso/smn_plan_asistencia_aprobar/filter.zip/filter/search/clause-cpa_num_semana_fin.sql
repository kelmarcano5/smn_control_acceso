 and
 	smn_plan_asistencia.cpa_num_semana_fin=${fld:cpa_num_semana_fin}