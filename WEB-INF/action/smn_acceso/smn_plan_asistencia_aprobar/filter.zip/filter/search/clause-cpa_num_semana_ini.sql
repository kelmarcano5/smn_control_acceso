 and
 	smn_plan_asistencia.cpa_num_semana_ini=${fld:cpa_num_semana_ini}