 and
 	smn_plan_asistencia.cpa_status=${fld:cpa_status}