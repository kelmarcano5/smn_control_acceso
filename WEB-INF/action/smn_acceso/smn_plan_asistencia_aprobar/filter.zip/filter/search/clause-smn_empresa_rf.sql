 and
 	smn_plan_asistencia.smn_empresa_rf = ${fld:smn_empresa_rf}