 and
 	smn_plan_asistencia.smn_esquema_rotacion_id = ${fld:smn_esquema_rotacion_id}