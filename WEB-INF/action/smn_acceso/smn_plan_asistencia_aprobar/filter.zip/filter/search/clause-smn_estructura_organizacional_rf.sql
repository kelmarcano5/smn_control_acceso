 and
 	smn_plan_asistencia.smn_estructura_organizacional_rf =${fld:smn_estructura_organizacional_rf}