 and
 	smn_plan_asistencia.smn_sucursal_rf = ${fld:smn_sucursal_rf}