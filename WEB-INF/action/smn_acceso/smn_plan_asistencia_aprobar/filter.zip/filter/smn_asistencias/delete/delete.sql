delete from smn_control_acceso.smn_asistencias where smn_asistencias_id = ${fld:id}
