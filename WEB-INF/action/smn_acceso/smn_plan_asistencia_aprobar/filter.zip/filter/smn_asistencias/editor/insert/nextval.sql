select ${seq:nextval@smn_control_acceso.seq_smn_asistencias} as id
