 and
 	smn_control_acceso.smn_asistencia.asi_auxiliar_rf=${fld:asi_auxiliar_rf}