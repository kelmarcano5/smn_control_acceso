 and
 	upper(smn_control_acceso.smn_asistencia.asi_estatus_asistencia_rf) like upper(${fld:asi_estatus_asistencia_rf})