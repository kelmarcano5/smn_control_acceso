 and
 	upper(smn_control_acceso.smn_asistencia.asi_estatus_permiso_rf) like upper(${fld:asi_estatus_permiso_rf})