 and
 	smn_control_acceso.smn_asistencia.asi_fecha>${fld:asi_fecha}