 and
 	smn_control_acceso.smn_asistencias.asi_fecha_registro<=${fld:asi_fecha_registro_fin}