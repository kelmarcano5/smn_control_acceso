 and
 	upper(smn_control_acceso.smn_asistencia.asi_id_control_acceso) like upper(${fld:asi_id_control_acceso})