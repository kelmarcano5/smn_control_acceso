 and
 	smn_control_acceso.smn_asistencia.asi_turno_rf=${fld:asi_turno_rf}