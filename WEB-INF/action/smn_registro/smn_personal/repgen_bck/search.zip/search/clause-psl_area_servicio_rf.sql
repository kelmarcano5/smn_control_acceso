 and
 	smn_control_acceso.smn_personal.psl_area_servicio_rf=${fld:psl_area_servicio_rf}