 and
 	smn_control_acceso.smn_personal.psl_auxiliar_rf=${fld:psl_auxiliar_rf}