 and
 	smn_control_acceso.smn_personal.psl_cargo_rf=${fld:psl_cargo_rf}