 and
 	smn_control_acceso.smn_personal.psl_centro_costo=${fld:psl_centro_costo}