 and
 	smn_control_acceso.smn_personal.psl_empresa_rf=${fld:psl_empresa_rf}