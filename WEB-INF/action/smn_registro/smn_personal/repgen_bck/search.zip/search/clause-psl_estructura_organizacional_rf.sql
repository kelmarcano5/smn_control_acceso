 and
 	smn_control_acceso.smn_personal.psl_estructura_organizacional_rf=${fld:psl_estructura_organizacional_rf}