 and
 	smn_control_acceso.smn_personal.psl_fecha_registro<=${fld:psl_fecha_registro_fin}