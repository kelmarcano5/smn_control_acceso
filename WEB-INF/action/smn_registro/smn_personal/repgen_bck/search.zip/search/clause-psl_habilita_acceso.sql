 and
 	upper(smn_control_acceso.smn_personal.psl_habilita_acceso) like upper(${fld:psl_habilita_acceso})