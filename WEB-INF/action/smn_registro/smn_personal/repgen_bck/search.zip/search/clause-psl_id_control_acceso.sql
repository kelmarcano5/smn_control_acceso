 and
 	upper(smn_control_acceso.smn_personal.psl_id_control_acceso) like upper(${fld:psl_id_control_acceso})