 and
 	smn_control_acceso.smn_personal.psl_sucursal_rf=${fld:psl_sucursal_rf}