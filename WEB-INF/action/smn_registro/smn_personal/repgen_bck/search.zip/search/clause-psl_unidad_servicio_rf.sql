 and
 	smn_control_acceso.smn_personal.psl_unidad_servicio_rf=${fld:psl_unidad_servicio_rf}