select 

  cva_cantidad_dias_pendientes
  
from smn_expedientes.smn_control_vacaciones
where smn_control_vacaciones_id=${fld:smn_control_vacaciones}